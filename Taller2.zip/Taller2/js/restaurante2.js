function comentario() {
    var textarea = document.getElementById("sug");
    var divsuger = document.getElementById("comentario");
    var click = document.getElementById("enviar");
    var editar = document.getElementById("textsugerencia");


    textarea.style.display = 'none';
    divsuger.style.display = 'block'
    divsuger.value = "";

    if(editar.addEventListener) {
        editar.addEventListener('click', edit, false);
    }

    
    
    function guardar() {
        divsuger.innerHTML = textarea.value;
        textarea.style.display = 'none';
        divsuger.style.display = 'block';
    }
    
    function edit() {
        textarea.innerHTML = divsuger.value;
        divsuger.style.display = 'none';
        textarea.style.display = 'block';
        textarea.focus();
    }
    
    document.addEventListener("keydown", function(e) {
        if(e.ctrlKey && e.key == "q") {
            edit();
        }
    })
    
    document.addEventListener("keydown", function(e) {
        if(e.ctrlKey && e.key == "k") {
            guardar();
        }
    })

    if(click.addEventListener) {
        click.addEventListener("click", guardar, false);
    }

}

if(window.addEventListener) {
    window.addEventListener("load", comentario, false);
}
