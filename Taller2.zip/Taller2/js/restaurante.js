function orden() {
    var total = 7.25;
    var totsinproduc;
    var textototal = document.getElementById("total");
    var click = document.getElementById("enviar");
    var checkboxes = document.querySelectorAll('.form-check-input');
    var array = [];
    var infopedido = document.getElementById("listapedido");
    var re = null;
    var mostrartotal = document.getElementById("pagar");
    var totpagar = null;

    //Combos
    textototal.value = total;
    array[0] = document.getElementById("combo1").value;
    document.getElementById("combo1").onclick = function() {
        if(document.getElementById("combo1").checked) {
            total = 0;
            total += 7.25;
            textototal.value = total; 
            totsinproduc = total;
            document.getElementById("ensalada").checked = false;
            document.getElementById("papas").checked = false;
            document.getElementById("piezagrande").checked = false;
            document.getElementById("piezamediana").checked = false;
            document.getElementById("piezapequena").checked = false;
            document.getElementById("bebidagrande").checked = false;
            document.getElementById("bebidamediana").checked = false;
            document.getElementById("bebidapequena").checked = false;
            document.getElementById("cafe").checked = false;
            document.getElementById("postre").checked = false;

            //Reiniciar arreglos y texto del pedido
            array = [];
            infopedido.innerHTML = "";
            mostrartotal.innerHTML = "";

        }
    }
    document.getElementById("combo2").onclick = function() {
        if(document.getElementById("combo2").checked) {
            total = 0;
            total += 5.75;
            textototal.value = total; 
            totsinproduc = total;
            document.getElementById("ensalada").checked = false;
            document.getElementById("papas").checked = false;
            document.getElementById("piezagrande").checked = false;
            document.getElementById("piezamediana").checked = false;
            document.getElementById("piezapequena").checked = false;
            document.getElementById("bebidagrande").checked = false;
            document.getElementById("bebidamediana").checked = false;
            document.getElementById("bebidapequena").checked = false;
            document.getElementById("cafe").checked = false;
            document.getElementById("postre").checked = false;

            //Reiniciar arreglos y texto del pedido
            array = [];
            infopedido.innerHTML = "";
            mostrartotal.innerHTML = "";
        }
    }
    document.getElementById("combo3").onclick = function() {
        if(document.getElementById("combo3").checked) {
            total = 0;
            total += 3.50;
            textototal.value = total; 
            totsinproduc = total;
            document.getElementById("ensalada").checked = false;
            document.getElementById("papas").checked = false;
            document.getElementById("piezagrande").checked = false;
            document.getElementById("piezamediana").checked = false;
            document.getElementById("piezapequena").checked = false;
            document.getElementById("bebidagrande").checked = false;
            document.getElementById("bebidamediana").checked = false;
            document.getElementById("bebidapequena").checked = false;
            document.getElementById("cafe").checked = false;
            document.getElementById("postre").checked = false;

            //Reiniciar arreglos y texto del pedido
            array = [];
            infopedido.innerHTML = "";
            mostrartotal.innerHTML = "";

        }
    }
    //Productos
    document.getElementById("ensalada").onclick = function() {
        if(document.getElementById("ensalada").checked) {
            textototal.value = (total+=1.50);
        }
        else if (!(document.getElementById("ensalada").checked)) {
            textototal.value = (total-=1.50);
            array.length -= 1;
        }
    }
    document.getElementById("papas").onclick = function() {
        if(document.getElementById("papas").checked) {
            textototal.value = (total+=1.25);
        }
        else if (!(document.getElementById("papas").checked)) {
            textototal.value = (total-=1.25);
            array.length -= 1;
        }
    }
    document.getElementById("piezagrande").onclick = function() {
        if(document.getElementById("piezagrande").checked) {
            textototal.value = (total+=1.75);
        }
        else if (!(document.getElementById("piezagrande").checked)) {
            textototal.value = (total-=1.75);
            array.length -= 1;
        }
    }
    document.getElementById("piezamediana").onclick = function() {
        if(document.getElementById("piezamediana").checked) {
            textototal.value = (total+=1.5);
        }
        else if (!(document.getElementById("piezamediana").checked)) {
            textototal.value = (total-=1.5);
            array.length -= 1;
        }
    }
    document.getElementById("piezapequena").onclick = function() {
        if(document.getElementById("piezapequena").checked) {
            textototal.value = (total+=1.25);
        }
        else if (!(document.getElementById("piezapequena").checked)) {
            textototal.value = (total-=1.25);
            array.length -= 1;
        }
    }
    document.getElementById("bebidagrande").onclick = function() {
        if(document.getElementById("bebidagrande").checked) {
            textototal.value = (total+=1.5);
        }
        else if (!(document.getElementById("bebidagrande").checked)) {
            textototal.value = (total-=1.5);
            array.length -= 1;
        }
    }
    document.getElementById("bebidamediana").onclick = function() {
        if(document.getElementById("bebidamediana").checked) {
            textototal.value = (total+=1.25);
        }
        else if (!(document.getElementById("bebidamediana").checked)) {
            textototal.value = (total-=1.25);
            array.length -= 1;
        }
    }
    document.getElementById("bebidapequena").onclick = function() {
        if(document.getElementById("bebidapequena").checked) {
            textototal.value = (total+=1);
        }
        else if (!(document.getElementById("bebidapequena").checked)) {
            textototal.value = (total-=1);
            array.length -= 1;
        }
    }
    document.getElementById("cafe").onclick = function() {
        if(document.getElementById("cafe").checked) {
            textototal.value = (total+=0.50);
        }
        else if (!(document.getElementById("cafe").checked)) {
            textototal.value = (total-=0.50);
            array.length -= 1;
        }
    }
    document.getElementById("postre").onclick = function() {
        if(document.getElementById("postre").checked) {
            textototal.value = (total+=1.25);
        }
        else if (!(document.getElementById("postre").checked)) {
            textototal.value = (total-=1.25);
            array.length -= 1;
        }
    }


    //Validar decimales
    mostrartotal.style.display = 'none';


    function decimal() {
        totpagar = parseFloat(textototal.value).toFixed(2);


        re = /^\d+(\.\d{2})?$/;
        if(re.test(totpagar)) {
            mostrartotal.style.display= 'block';
            mostrartotal.innerHTML = "Total a pagar: $" + totpagar;
        }
    }


    //Array de Información de Pedido

    for(var check_box of checkboxes) {
        check_box.addEventListener('click', function() {
            if(this.checked == true) {
                array.push(" " + this.value)
            }
        })
    }

    function pedidoinfo() {
        infopedido.innerHTML = array;
    }

    if(click.addEventListener) {
        click.addEventListener('click', pedidoinfo, false)
        click.addEventListener('click', decimal, false)
    }
}

if(window.addEventListener) {
    window.addEventListener('load', orden, false)
}