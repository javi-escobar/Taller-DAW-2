function inti() {
    var click = document.getElementById("enviar")
    var arraylibro = [];
    var ingresocorrecto;


    if(click.addEventListener) {
        click.addEventListener('click',validar, false);
        click.addEventListener('click', mostrarlibros, false);
    }

    
    function validar() {
        var idlibro = document.getElementById("libroid").value;
        var tituloli = document.getElementById("titulo").value;
        var nombreau = document.getElementById("nombre").value;
        var apellau = document.getElementById("apellido").value;
        var categ = document.getElementById("categoria").value;
        var precio = document.getElementById("precio").value;
        var img = document.getElementById("imagen").files;
        var re = null;
        var libro = [];
        ingresocorrecto = false;
    
        //Validaciones
        if(idlibro == "" || idlibro == null || idlibro.length == 0) {
            ingresocorrecto = false;
            alert("No ha ingresado el id del libro");
            return 0;
        }
        else {
            var contgu = 0;
            var guion = "-";
            for(var i = 0; i<idlibro.length; i++) {
                if(idlibro[i] == guion && idlibro[i] !== idlibro[i-1] && idlibro[0] !== guion) {
                    contgu++;
                }
            }
            re =  /^(\d+)-(\d+)-(\d+)-(\d+)-(\d{1})$/;
            if(idlibro.length == 17 && contgu == 4 && re.test(idlibro)) {
                    ingresocorrecto = true;
            }
            else {
                ingresocorrecto = false;
                alert("ID de libro no válido");
                return 0;
            }
        }


        if(tituloli == "" || tituloli == null || tituloli.length == 0) {
            ingresocorrecto = false;
            alert("No ha ingresado el titulo del libro");
            return 0;
        }
        else {
            re =/^[a-zA-ZÑñáéíóúÁÉÍÓÚ][a-zA-ZÑñáéíóúÁÉÍÓÚ\s]*$/;
            if(re.test(tituloli)) {
                ingresocorrecto = true;
                libro.push(tituloli);
            }
            else {
                ingresocorrecto = false;
                alert("Titulo incorrecto, solo se permiten letras sin espacios al principio, revisar campo");
                return 0;
            }
        }


        if(nombreau == "" || nombreau == null || nombreau.length == 0) {
            ingresocorrecto = false;
            alert("No ha ingresodo el nombre del autor")
            return 0;
        }
        else {
            re = /^[a-zA-ZÑñáéíóúÁÉÍÓÚ][a-zA-ZÑñáéíóúÁÉÍÓÚ\s]*$/;
            if(re.test(nombreau)) {
                ingresocorrecto = true;
                libro.push(nombreau)
            }
            else {
                ingresocorrecto = false;
                alert("Nombre incorrecto, solo se permiten letras sin espacios al principio, revisar campo");
                return 0;
            }
        }


        if(apellau == "" || apellau == null || apellau.length == 0) {
            ingresocorrecto = false;
            alert("No ha ingresado el apellido del autor")
            return 0;
        }
        else {
            re = /^[a-zA-ZÑñáéíóúÁÉÍÓÚ][a-zA-ZÑñáéíóúÁÉÍÓÚ\s]*$/;
            if(re.test(apellau)) {
                ingresocorrecto = true;
                libro.push(apellau);
            }
            else {
                ingresocorrecto = false;
                alert("Apellido incorrecto, solo se permiten letras sin espacios al principio, revisar campo");
                return 0;
            }
        }


        if(precio <= 0 || precio == null) {
            ingresocorrecto = false;
            alert("Ingrese un precio válido, entero o de dos decimales")
            return 0;
        }
        else {
            re =/^\d+(\.\d{2})?$/;
            if(re.test(precio)) {
                ingresocorrecto = true;
                libro.push(precio);
            }
            else {
                ingresocorrecto = false;
                alert("Ingrese un precio válido, entero o de dos decimales");
                return 0;
            }
        }


        //Imagen
        const inputimg = document.getElementById("imagen");
        if(img == null || img.length <= 0) {
            ingresocorrecto = false;
            alert("No ha subido ninguna imagen")
            return 0;
        }
        else {
            var urlimg = document.getElementById("imagen").files[0].name;
            for(var i = 0; i<inputimg.files.length; i++) {
                const srcimg = inputimg.files[i];
                re = /(.jpg|.jpeg|.png|.gif)$/;
                if(re.test(urlimg)){
                    var ubimg = URL.createObjectURL(srcimg);
                    libro.push(ubimg);
                }
                else {
                    ingresocorrecto = false;
                    alert("Solo se permiten imagenes .jpg, .jpeg, .png, .gif");
                    return 0;
                }
            }
        }

        ingresocorrecto = true;

        //Arreglo de arreglos que almacena toda la informacion del libro que se mostrará
        if(ingresocorrecto == true) {
            arraylibro.push(libro)
        };

        //Limpiar campos
        formulario.reset();
    }

    function mostrarlibros() {
        const p = document.createElement("p");
        const img = document.createElement("img");
        var col1 = document.getElementById("colum1");
        var col2 = document.getElementById("colum2");
        
        if(ingresocorrecto == true) {
            for(var i = 0; i<arraylibro.length; i++) {
                p.innerText = "Titulo: " + arraylibro[i][0] + "\nAutor: " + arraylibro[i][1] + " " + arraylibro[i][2] + "\nPrecio: $"  + arraylibro[i][3] + "\n";
                img.src = arraylibro[i][4];
                if(i % 2 !== 0) {
                    col1.append(img);
                    col1.append(p);
                }
                else if(i%2 == 0) {
                    col2.append(img);
                    col2.append(p);
                }
            }
        }
    
    }
    
}

if(window.addEventListener) {
    window.addEventListener('load', inti, false );
}